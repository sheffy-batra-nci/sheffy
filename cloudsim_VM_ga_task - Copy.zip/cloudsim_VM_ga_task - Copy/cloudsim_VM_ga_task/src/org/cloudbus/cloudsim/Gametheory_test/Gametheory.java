package org.cloudbus.cloudsim.Gametheory_test;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;

public class Gametheory {

    public static double evaluateStrategy(Vm vm, Host[] hosts) {

        // Define a distance threshold for dynamic neighborhood
        final double DISTANCE_THRESHOLD = 100.0; // Adjust as needed

        double totalCapacity = 0;
        int neighborCount = 0;
        if (vm.getHost() == null) {
            // Handle the case where the host is null, e.g., return a default value
            return 0.0;
        }
    /*   for (Host neighbor : hosts) {
            if (!neighbor.equals(vm.getHost())) {
                totalCapacity += neighbor.getAvailableMips(); // Adjust this based on your requirements
                neighborCount++;
            }}
   */  
        for (Host neighbor : hosts) {
            if (!neighbor.equals(vm.getHost()) && isWithinDistance(vm.getHost(), neighbor, DISTANCE_THRESHOLD)) {
                totalCapacity += neighbor.getAvailableMips();
                neighborCount++;
            }
        }

        // Calculate the average capacity of neighbors
        double averageCapacity = (neighborCount > 0) ? totalCapacity / neighborCount : 0;

        // Compare the capacity of the current VM's host with the average capacity of neighbors
        double utility = vm.getHost().getAvailableMips() - averageCapacity;

        // Return a value representing the utility or effectiveness of the allocation
        return utility;
    }
    
    public static boolean isWithinDistance(Host host1, Host host2, double dISTANCE_THRESHOLD) {
        int idDifference = Math.abs(host1.getId() - host2.getId());
        return idDifference <= dISTANCE_THRESHOLD;
    }



}

