package org.cloudbus.cloudsim.power;

public abstract class Location {
	protected Domain domain;

	public Location(){}
	
	public Location(Domain domain){
		this.domain = domain;
	}
	
	public abstract void generateRandomLocation(int id);
	public abstract double computeDistanceTo(Location location);
	public abstract Location computeNewLocation(Location towardsLocation, double stepSize);

	public Domain getDomain() {
		return domain;
	}

	
	

}
