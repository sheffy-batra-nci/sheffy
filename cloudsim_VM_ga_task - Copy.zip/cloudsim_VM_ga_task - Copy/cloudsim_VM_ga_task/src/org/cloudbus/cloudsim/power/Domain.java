package org.cloudbus.cloudsim.power;

public abstract class Domain {

	public Domain() {
		// TODO Auto-generated constructor stub
	}

}
